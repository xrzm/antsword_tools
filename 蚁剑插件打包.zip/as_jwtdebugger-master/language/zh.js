module.exports = {
  title: "JWT 调试",
  success: "操作成功",
  error: "操作失败",
  toolbar: {
    start: "开始",
    reset: "重置",
  },
}
