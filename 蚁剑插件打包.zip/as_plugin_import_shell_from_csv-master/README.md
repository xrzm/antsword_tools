# 批量导入Shell

从 CSV 中 批量导入 Shell

## Example

```csv
恭喜你发现使用说明书！
CSV格式：
**备注,分类,密码,类型,Shell地址**
举个例子：
测试1,test,pass,php,http://gov.cn/666.php
测试2,test,pass,php,http://fbi.com/warning.php
测试3,test,666,php,https://www.virzz.com/vk.php
```

## ???

任性挖坑，随缘填坑

**欢迎 PR，坚决不更**
