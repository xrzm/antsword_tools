module.exports = {
    title: "Import Shell",
    success: "Ret Success",
    error: "Ret Error",
    toolbar: {
        import: "Import",
        clear: "Clear",
    },
    confirm: {
        content: "Exit the program, manually restart to take effect, whether to quit?",
        title: "Import Shell"
    }
}