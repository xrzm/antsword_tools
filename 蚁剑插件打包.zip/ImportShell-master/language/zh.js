module.exports = {
    title: "导入Shell",
    success: "导入成功",
    error: "导入失败",
    toolbar: {
        import: "导入",
        clear: "清空",
    },
    confirm: {
        content: "退出程序，手动重启生效，是否退出？",
        title: "导入配置"
    }
}