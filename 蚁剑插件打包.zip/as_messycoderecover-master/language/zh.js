module.exports = {
  title: "乱码恢复",
  success: "操作成功",
  error: "操作失败",
  cell: {
    cella: '输入',
    cellb: '转换结果',
  },
  form: {
    inputtext: '乱码文本',
  },
  grid: {
    encoding: '字符编码',
    result: '结果',
  },
  toolbar: {
    start: "自动恢复",
    reset: "重置",
    online: "在线工具",
  },
}
