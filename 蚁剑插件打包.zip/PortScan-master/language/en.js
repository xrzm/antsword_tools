module.exports = {
    title: "PortScan",
    success: "Ret Success",
    error: "Ret Error",
    cella: {
        title: "Target",
        start: "Start",
        form: {
            ip: "IP",
            ports: "Ports"
        }
    },
    cellb: {
        title: "Result",
        grid: {
            ip: "IP",
            port: "Port",
            status: "Status"
        }
    }
}