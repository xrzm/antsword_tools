# WebShell查杀

通过正则匹配，查找后门 webshell

## 演示截图

![demo.png](https://i.loli.net/2019/09/02/f89EeDzq3BrAmNJ.png)

## TODO

- [x] PHP
- [ ] ASP
- [ ] ASPX
- [ ] JAVA