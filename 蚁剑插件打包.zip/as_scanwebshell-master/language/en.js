module.exports = {
  title: "ScanWebShell",
  success: "success",
  error: "fail",
  toolbar: {
    start: "Start"
  },
  grid: {
    name: "File",
    line: "Line",
    code: "Code",
  },
}