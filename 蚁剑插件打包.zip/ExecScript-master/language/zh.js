module.exports = {
    title: "脚本执行",
    success: "执行成功",
    error: "执行失败",
    cella: {
        title: "脚本编辑",
        start: "执行",
        clear:  "清空",
        script: "类型:",
    },
    cellb: {
        title: "执行结果",
    }
}