/**
 * zh_CN
 */

module.exports = {
    title: "植入不死php webshell",
    toolbar: {
        new: "远端文件"
    },
    message: {
        inject_success: "植入成功,远程控制文件已被记录!"
    },
    prompt: {
        rm_file: "请输入远端控制文件地址及轮询时间(以###分隔)"
    },
    cell:{
        path:"历史远端控制文件"
    },
    error:{
        wrong:"植入失败",
        value_wrong:"输入非法，请输入有效的轮询时间或检查分隔符是否为\'###\'！"
    }

};
