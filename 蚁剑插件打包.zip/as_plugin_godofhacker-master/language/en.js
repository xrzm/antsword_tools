module.exports = {
  title: "God Of Hacker",
  success: "success",
  error: "fail",
  target_null: "Plz input the target!!!",
  attacking: "Attacking...",
  form: {
    task_title: "Task Target",
    target: "Target",
    pretesting: "Pretesting",
    auto_attack: "Auto Attack",
  },
  tabs: {
    web: {
      title: "Web",
      form: {
        vuls_attack: "Vulnerability Attack",
        vulns: "Vulnerabilities",
        exp_attack: "Exp Attack",
        priviledge: "Priviledge",
        onekeyattack: "OneKey Attack"
      }
    },
    ctf: {
      title: "CTF",
      form: {
        onekeyattack: "OneKey Attack"
      }
    },
    crack: {
      title: "Crack",
      form: {
        onekeyattack: "OneKey Crack"
      }
    },
    wireless: {
      title: "Wireless",
      form: {
        onekeyattack: "OneKey Attack"
      }
    },
    hardware: {
      title: "Hardware",
      form: {
        onekeyattack: "OneKey Attack"
      }
    },
    others: {
      title: "Others",
      form: {
        onekeyattack: "OneKey Attack"
      }
    },
    about: {
      title: "About"
    }
  },
  web: {
    backdoor: {
      name: "Backdoor",
      msg: "Okey, guy. You got it!"
    },
    hackerpage: {
      name: 'Hacker Page',
      msg: ['666666666666', "Hacker Page is beautiful"]
    },
    admindir: {
      name: 'Admin Dir',
      msg: ''
    },
    adminaccount: {
      name: 'Admin Account',
      msg: ''
    },
    getshell: {
      name: 'Get Shell',
      msg: ''
    },
    pulldatabase: {
      name: 'Pull Database',
      msg: ''
    },
    ddos: {
      name: 'DDOS Attack',
      msg: ''
    },
    reverseshell: {
      name: 'Reverse Shell',
      msg: ''
    },
    packagesite: {
      name: 'Package Site',
      msg: ''
    },
    deepnetroam: {
      name: 'DeepNet Roam',
      msg: ''
    },
    tunnelproxy: {
      name: 'Tunnel Proxy',
      msg: ''
    },
    vpnproxy: {
      name: 'VPN Proxy',
      msg: ''
    },
    freenetwork: {
      name: 'Free Network',
      msg: ''
    },
    fucknetbar: {
      name: 'Fuck Net Bar',
      msg: ''
    },
    fuckedusys: {
      name: 'Fuck Edu Sys',
      msg: ''
    },
    fuckqq: {
      name: 'Fuck QQ',
      msg: ''
    },
    fuckwechat: {
      name: 'Fuck WeChat',
      msg: ''
    },
    fuckcmcc: {
      name: 'Fuck CMCC',
      msg: ''
    },
    fuckcu: {
      name: 'Fuck CU',
      msg: ''
    },
    fuckct: {
      name: 'Fuck CT',
      msg: ''
    },
    supervip: {
      name: 'Super VIP',
      msg: ''
    },
    getbtc: {
      name: 'Get BTC',
      msg: ''
    },
    innernet: {
      name: 'Inner Net',
      msg: ''
    },
    debug: {
      name: 'Debug Program',
      msg: ''
    },
    fixbug: {
      name: 'Fix Bugs',
      msg: ''
    },
    auditcode: {
      name: 'Audit Code',
      msg: ''
    },
    issuevul: {
      name: 'Issue Vulns',
      msg: ''
    },
    rmrf: {
      name: 'rm -rf /*',
      msg: ''
    },
    gitclone: {
      name: 'Git Clone',
      msg: ''
    },
    godie: {
      name: 'Go Die',
      msg: ''
    }
  },
  ctf: {
    joinctfgroup: {
      name: 'Join CTF Group',
      msg: null
    },
    defense: {
      name: 'Absolute Defense',
      msg: function (l, t) {
        l.open({
          type: 1,
          title: false,
          skin: 'layui-bg-black',
          closeBtn: 0,
          anim: 2,
          time: 3000,
          area: '500px',
          shadeClose: true,
          content: `<span style="font-size:40px"># mv ~ /dev/null<br /># grep root /etc/nmap<br /># nmap -sT -A ${t ? t : 'localhost'}<br />Congratulations</span>`
        });
      }
    },
    findpoint: {
      name: 'Find Point',
      msg: ''
    },
    findvul: {
      name: 'Find Vuln',
      msg: ''
    },
    getshell: {
      name: 'Get Shell',
      msg: ''
    },
    nodieshell: {
      name: 'No Die Shell',
      msg: ''
    },
    getflag: {
      name: 'Get Flag',
      msg: ''
    },
    stealflag: {
      name: 'Steal Flag',
      msg: ''
    },
    deleteflag: {
      name: 'Delete Flag',
      msg: ''
    },
    changeflag: {
      name: 'Change Flag',
      msg: ''
    },
    pyflag: {
      name: 'PY Flag',
      msg: ''
    },
    writeups: {
      name: 'Writeups',
      msg: ''
    },
    maketrouble: {
      name: 'Make Trouble',
      msg: ''
    },
    brokennet: {
      name: 'Broken Net',
      msg: ''
    },
    chaangerank: {
      name: 'Change Rank',
      msg: ''
    },
    fucksystem: {
      name: 'Fuck System',
      msg: ''
    },
    fuckmaker: {
      name: 'Fuck Challenge Maker',
      msg: ''
    },
    postzhihu: {
      name: 'Post Zhihu',
      msg: ''
    }
  },
  crack: {},
  wireless: {},
  hardware: {},
  others: {
    iplocation: {
      name: 'IP Location',
      msg: ''
    }
  },
  about: {}
}